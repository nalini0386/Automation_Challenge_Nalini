package AutomationChallenge;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Challenge5 {

	public static void main(String[] args) {

		String text1 = "Power of technology";
		String uCase1 = text1.toUpperCase();
		String text2 = "Technology is powerful";
		String uCase2 = text2.toUpperCase();
		text2.toUpperCase();
		String[] text1Split = uCase1.split(" ");
		String[] text2Split = uCase2.split(" ");
		List<String> list = new ArrayList<String>(Arrays.asList(text1Split));
		list.addAll(Arrays.asList(text2Split));
		Map<String, Integer> map = new HashMap<String, Integer>();
		Set<String> set = new HashSet<String>();

		try {
			for (String text : list) {
				if (set.add(text) == false) {
					int len = text.length();
					map.put(text, len);
				}
			}
			int maxValueInMap = (Collections.max(map.values()));

			for (Entry<String, Integer> entry : map.entrySet()) {
				if (entry.getValue() == maxValueInMap) {

					// Print the key with max value
					System.out.println("Longest shared SubString is:" + entry.getKey());
				}
			}
		} catch (Exception e) {
			System.out.println("No shared/matching substring");
		}
	}
}
