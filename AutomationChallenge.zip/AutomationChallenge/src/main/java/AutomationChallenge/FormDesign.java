package AutomationChallenge;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class FormDesign implements ActionListener {

	JTextField nonEditText, editText;
	JLabel label1, label2;
	JButton btnSubmit;
	String userinput;
	JFrame frame;
	int counter;
	int validRand;
	int maxRandValue;

	FormDesign() {

		// frame designing

		frame = new JFrame("Math Game");
		label1 = new JLabel("Computer has generated the random number");
		label1.setBounds(50, 10, 400, 200);
		nonEditText = new JTextField("xxxxx");
		nonEditText.setBounds(75, 125, 100, 30);
		nonEditText.setEditable(false);
		label2 = new JLabel("Enter your input(range: 1-10)");
		label2.setBounds(50, 200, 400, 200);
		frame.add(label2);
		editText = new JTextField("");
		editText.setBounds(75, 325, 100, 30);
		frame.add(editText);
		btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(50, 400, 200, 50);
		btnSubmit.addActionListener(this);
		frame.add(btnSubmit);
		frame.add(label1);
		frame.add(nonEditText);
		frame.add(editText);
		frame.add(label2);
		frame.setSize(600, 600);
		frame.setLayout(null);
		frame.setVisible(true);
		counter = 1;

		Random random = new Random();
		validRand = random.nextInt(11);
		maxRandValue = 10;

	}

	public static void main(String[] args) {
		new FormDesign();

	}
	


	public void actionPerformed(ActionEvent e) {

		try {

			// this will loop the iteration till maximum 5 retries attempted by user

			if (counter <= 5) {
				userinput = editText.getText();
				int valueToCompare = Integer.parseInt(userinput);

				if (valueToCompare < 0) {
					editText.requestFocus();
					JOptionPane.showMessageDialog(frame, "You have entered negative number!Try again", "Info",
							JOptionPane.YES_OPTION);
					editText.setText("");
					editText.requestFocus();

				}

				else if (valueToCompare < validRand && valueToCompare != 0) {
					JOptionPane.showMessageDialog(frame, "Your guess is low", "Info", JOptionPane.YES_OPTION);
					editText.setText("");
					editText.requestFocus();
				} else if (valueToCompare == validRand) {
					JOptionPane.showMessageDialog(frame,
							"Congratulations!!You guessed the answer in " + counter + " attempts", "Info",
							JOptionPane.YES_OPTION);
					editText.setEditable(false);
					btnSubmit.setEnabled(false);

				} else if ((valueToCompare > maxRandValue) || (valueToCompare == 0)) {
					JOptionPane.showMessageDialog(frame, "Enter the correct NUMBER range", "Info",
							JOptionPane.YES_OPTION);
					editText.setText("");
					editText.requestFocus();
				}

				else {
					JOptionPane.showMessageDialog(frame, "Your guess is high", "Info", JOptionPane.YES_OPTION);
					editText.setText("");
					editText.requestFocus();
				}
				counter++;

			}

			else {
				JOptionPane.showMessageDialog(frame, "You have reached maximum Retries", "Info",
						JOptionPane.YES_OPTION);
				editText.setEditable(false);
			}

		}

		catch (Exception e1) {
			JOptionPane.showMessageDialog(frame, "Invalid Numeric characters are entered", "Info",
					JOptionPane.YES_OPTION);
			counter++;

		}
	}

}
